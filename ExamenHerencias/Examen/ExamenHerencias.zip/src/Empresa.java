public class Empresa {
    public static final int NUMERO = 3;

    public static void main(String[] args) {
        Empleado[] misEmpleado = new Empleado[NUMERO];

        misEmpleado[0] = new Tecnico("Juan Pérez", 38, "T003", 2100, 5, "pp");
        misEmpleado[1] = new Gestor("Ana González", 43, "G017", 3000, 8, 65000);
        misEmpleado[2] = new Administrativo("Carlos Cieza", 34, "A009", 1500, 2, "Recursos humanos");

        for (int i = 0; i < NUMERO; i++) {
            System.out.println(misEmpleado[i].toString());
            System.out.println("");
        }
        System.out.println("");
        System.out.println("");

        for (int i = 0; i < NUMERO; i++) {
            ((CalculosLaborales) misEmpleado[i]).calcularSalario();
            System.out.println("");
        }

        System.out.println("");
        System.out.println("");

        for (int i = 0; i < NUMERO; i++) {
            ((CalculosLaborales) misEmpleado[i]).calcularVacaciones();
            System.out.println("");
        }

        System.out.println("Tienes un total de "+ Empleado.getTotalEmpleados()  +" empleados.");

    }
}
