abstract class Empleado {
    private String nombre ;
    private int edad ;
    private String idEmpleado ;
    private double salarioBase ;
    private int anosDeTrabajo ;
    private static int totalEmpleados=0;
    /**
     * Creo el constructor de Empleado 
     * @param nombre
     * @param edad
     * @param idEmpleado
     * @param salarioBase
     * @param anosDeTrabajo
     */
    public Empleado (String nombre, int edad, String idEmpleado, double salarioBase, int anosDeTrabajo){
        this.nombre=nombre;
        this.edad= edad;
        this.idEmpleado=idEmpleado;
        this.salarioBase=salarioBase;
        this.anosDeTrabajo= anosDeTrabajo;
        totalEmpleados++;
    }



    public void setAnosDeTrabajo(int anosDeTrabajo) {
        this.anosDeTrabajo = anosDeTrabajo;
    }
    public int getAnosDeTrabajo() {
        return anosDeTrabajo;
    }



    public void setEdad(int edad) {
        this.edad = edad;
    }
    public int getEdad() {
        return edad;
    }



    public void setIdEmpleado(String idEmpleado) {
        this.idEmpleado = idEmpleado;
    }
    public String getIdEmpleado() {
        return idEmpleado;
    }



    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }



    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }
    public double getSalarioBase() {
        return salarioBase;
    }


    public static int getTotalEmpleados() {
        return totalEmpleados;
    }


    public String toString() {
        String frase="Empleado: "+nombre+", Edad: "+edad+", Id: "+idEmpleado+", Salario base: "+salarioBase;
        frase+=", Años de trabajo: "+anosDeTrabajo;
        return frase;
    }
}
