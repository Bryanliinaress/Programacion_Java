public class SistemaGestionEstudiantes {
    public static void main(String[] args) {
        
        GestionEstudiantes.registrarEstudiante("estudiante1");

        GestionEstudiantes.mostrarEstudiante();

        GestionEstudiantes.registrarEstudiante("estudiante2");
        
        GestionEstudiantes.mostrarEstudiante();
    }
}
